﻿namespace Mobile_Shop_Management_System
{
    partial class Selling
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Selling));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Mobile = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Product = new System.Windows.Forms.Label();
            this.Price = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Bill = new System.Windows.Forms.TextBox();
            this.Quantity1 = new System.Windows.Forms.TextBox();
            this.price1 = new System.Windows.Forms.TextBox();
            this.product1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.mobiledgv = new System.Windows.Forms.DataGridView();
            this.AcessDGV = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.BillDGV = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button2 = new System.Windows.Forms.Button();
            this.amount = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.button3 = new System.Windows.Forms.Button();
            this.ClientName = new System.Windows.Forms.TextBox();
            this.Client = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.sellamt = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.SellsAmount = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.mobiledgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AcessDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BillDGV)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Coral;
            this.label1.Location = new System.Drawing.Point(411, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(389, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mobile  Management Sytem";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label2.Location = new System.Drawing.Point(496, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 35);
            this.label2.TabIndex = 1;
            this.label2.Text = "Selling";
            // 
            // Mobile
            // 
            this.Mobile.AutoSize = true;
            this.Mobile.Location = new System.Drawing.Point(530, 120);
            this.Mobile.Name = "Mobile";
            this.Mobile.Size = new System.Drawing.Size(107, 35);
            this.Mobile.TabIndex = 2;
            this.Mobile.Text = "Mobile";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(905, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(163, 35);
            this.label4.TabIndex = 3;
            this.label4.Text = "Accessories";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Cursor = System.Windows.Forms.Cursors.Default;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(9, 172);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 29);
            this.label5.TabIndex = 4;
            this.label5.Text = "Bill Id";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // Product
            // 
            this.Product.AutoSize = true;
            this.Product.Font = new System.Drawing.Font("Microsoft Tai Le", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product.Location = new System.Drawing.Point(9, 223);
            this.Product.Name = "Product";
            this.Product.Size = new System.Drawing.Size(98, 29);
            this.Product.TabIndex = 5;
            this.Product.Text = "Product";
            // 
            // Price
            // 
            this.Price.AutoSize = true;
            this.Price.Font = new System.Drawing.Font("Microsoft Tai Le", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Price.Location = new System.Drawing.Point(9, 271);
            this.Price.Name = "Price";
            this.Price.Size = new System.Drawing.Size(66, 29);
            this.Price.TabIndex = 6;
            this.Price.Text = "Price";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Tai Le", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(9, 328);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 29);
            this.label8.TabIndex = 7;
            this.label8.Text = "Quantity";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.LightCoral;
            this.button1.Location = new System.Drawing.Point(151, 386);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(147, 41);
            this.button1.TabIndex = 8;
            this.button1.Text = "Add To Bill";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Bill
            // 
            this.Bill.Location = new System.Drawing.Point(151, 172);
            this.Bill.Multiline = true;
            this.Bill.Name = "Bill";
            this.Bill.Size = new System.Drawing.Size(172, 38);
            this.Bill.TabIndex = 9;
            // 
            // Quantity1
            // 
            this.Quantity1.Location = new System.Drawing.Point(151, 328);
            this.Quantity1.Multiline = true;
            this.Quantity1.Name = "Quantity1";
            this.Quantity1.Size = new System.Drawing.Size(172, 29);
            this.Quantity1.TabIndex = 10;
            // 
            // price1
            // 
            this.price1.Location = new System.Drawing.Point(151, 271);
            this.price1.Multiline = true;
            this.price1.Name = "price1";
            this.price1.Size = new System.Drawing.Size(172, 29);
            this.price1.TabIndex = 11;
            this.price1.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // product1
            // 
            this.product1.Location = new System.Drawing.Point(151, 216);
            this.product1.Multiline = true;
            this.product1.Name = "product1";
            this.product1.Size = new System.Drawing.Size(172, 36);
            this.product1.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(815, 310);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 35);
            this.label3.TabIndex = 13;
            this.label3.Text = "Bill";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // mobiledgv
            // 
            this.mobiledgv.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.mobiledgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.mobiledgv.GridColor = System.Drawing.Color.MistyRose;
            this.mobiledgv.Location = new System.Drawing.Point(410, 173);
            this.mobiledgv.Name = "mobiledgv";
            this.mobiledgv.RowHeadersWidth = 51;
            this.mobiledgv.RowTemplate.Height = 24;
            this.mobiledgv.Size = new System.Drawing.Size(359, 123);
            this.mobiledgv.TabIndex = 28;
            this.mobiledgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.mobiledgv_CellContentClick);
            // 
            // AcessDGV
            // 
            this.AcessDGV.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.AcessDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AcessDGV.GridColor = System.Drawing.Color.MistyRose;
            this.AcessDGV.Location = new System.Drawing.Point(798, 173);
            this.AcessDGV.Name = "AcessDGV";
            this.AcessDGV.RowHeadersWidth = 51;
            this.AcessDGV.RowTemplate.Height = 24;
            this.AcessDGV.Size = new System.Drawing.Size(357, 123);
            this.AcessDGV.TabIndex = 30;
            this.AcessDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AcessDGV_CellContentClick);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Copperplate Gothic Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.IndianRed;
            this.label9.Location = new System.Drawing.Point(1200, 19);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 25);
            this.label9.TabIndex = 31;
            this.label9.Text = "X";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // BillDGV
            // 
            this.BillDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.BillDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.BillDGV.Location = new System.Drawing.Point(572, 348);
            this.BillDGV.Name = "BillDGV";
            this.BillDGV.RowHeadersWidth = 51;
            this.BillDGV.RowTemplate.Height = 24;
            this.BillDGV.Size = new System.Drawing.Size(583, 202);
            this.BillDGV.TabIndex = 32;
            this.BillDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Id";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.Width = 70;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Product";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.Width = 114;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Price";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.Width = 114;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Quantity";
            this.Column4.MinimumWidth = 6;
            this.Column4.Name = "Column4";
            this.Column4.Width = 114;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Total";
            this.Column5.MinimumWidth = 6;
            this.Column5.Name = "Column5";
            this.Column5.Width = 114;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.LightCoral;
            this.button2.Location = new System.Drawing.Point(798, 620);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(147, 41);
            this.button2.TabIndex = 33;
            this.button2.Text = "Print";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // amount
            // 
            this.amount.AutoSize = true;
            this.amount.Location = new System.Drawing.Point(847, 566);
            this.amount.Name = "amount";
            this.amount.Size = new System.Drawing.Size(123, 35);
            this.amount.TabIndex = 34;
            this.amount.Text = "Amount";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(792, 566);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 35);
            this.label6.TabIndex = 35;
            this.label6.Text = "RS";
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            this.printPreviewDialog1.Load += new System.EventHandler(this.printPreviewDialog1_Load);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(151, 592);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(144, 36);
            this.button3.TabIndex = 36;
            this.button3.Text = "Back";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // ClientName
            // 
            this.ClientName.Location = new System.Drawing.Point(151, 120);
            this.ClientName.Multiline = true;
            this.ClientName.Name = "ClientName";
            this.ClientName.Size = new System.Drawing.Size(172, 35);
            this.ClientName.TabIndex = 38;
            // 
            // Client
            // 
            this.Client.AutoSize = true;
            this.Client.Cursor = System.Windows.Forms.Cursors.Default;
            this.Client.Font = new System.Drawing.Font("Microsoft Tai Le", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Client.Location = new System.Drawing.Point(9, 126);
            this.Client.Name = "Client";
            this.Client.Size = new System.Drawing.Size(76, 29);
            this.Client.TabIndex = 37;
            this.Client.Text = "Client";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel1.Controls.Add(this.SellsAmount);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.sellamt);
            this.panel1.Location = new System.Drawing.Point(109, 449);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(236, 114);
            this.panel1.TabIndex = 39;
            // 
            // sellamt
            // 
            this.sellamt.AutoSize = true;
            this.sellamt.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sellamt.ForeColor = System.Drawing.SystemColors.Highlight;
            this.sellamt.Location = new System.Drawing.Point(60, 13);
            this.sellamt.Name = "sellamt";
            this.sellamt.Size = new System.Drawing.Size(116, 22);
            this.sellamt.TabIndex = 2;
            this.sellamt.Text = "Sells Amount";
            this.sellamt.Click += new System.EventHandler(this.label7_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label10.Location = new System.Drawing.Point(40, 53);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(28, 22);
            this.label10.TabIndex = 3;
            this.label10.Text = "Rs";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // SellsAmount
            // 
            this.SellsAmount.AutoSize = true;
            this.SellsAmount.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SellsAmount.ForeColor = System.Drawing.SystemColors.Highlight;
            this.SellsAmount.Location = new System.Drawing.Point(74, 53);
            this.SellsAmount.Name = "SellsAmount";
            this.SellsAmount.Size = new System.Drawing.Size(75, 22);
            this.SellsAmount.TabIndex = 4;
            this.SellsAmount.Text = "Amount";
            // 
            // Selling
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 34F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1241, 673);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ClientName);
            this.Controls.Add(this.Client);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.amount);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.BillDGV);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.AcessDGV);
            this.Controls.Add(this.mobiledgv);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.product1);
            this.Controls.Add(this.price1);
            this.Controls.Add(this.Quantity1);
            this.Controls.Add(this.Bill);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Price);
            this.Controls.Add(this.Product);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Mobile);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Tai Le", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Selling";
            this.Text = "Sellingcs";
            this.Load += new System.EventHandler(this.Selling_Load);
            ((System.ComponentModel.ISupportInitialize)(this.mobiledgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AcessDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BillDGV)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Mobile;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Product;
        private System.Windows.Forms.Label Price;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Bill;
        private System.Windows.Forms.TextBox Quantity1;
        private System.Windows.Forms.TextBox price1;
        private System.Windows.Forms.TextBox product1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView mobiledgv;
        private System.Windows.Forms.DataGridView AcessDGV;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView BillDGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label amount;
        private System.Windows.Forms.Label label6;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox ClientName;
        private System.Windows.Forms.Label Client;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label sellamt;
        private System.Windows.Forms.Label SellsAmount;
    }
}