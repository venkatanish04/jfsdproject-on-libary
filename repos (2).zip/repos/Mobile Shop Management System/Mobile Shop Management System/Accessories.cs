﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Diagnostics;
using System.Security.Cryptography;
namespace Mobile_Shop_Management_System
{
    public partial class Accessories : Form
    {
        public Accessories()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-0QOGVAC\SQLEXPRESS02;Initial Catalog=MobileTbl;Integrated Security=True");
        private void populate()
        {
            Con.Open();
            string query = "select * from Accessories";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder buider = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            AcessDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void Add_Click(object sender, EventArgs e)
        {
            // Check if all required fields are filled
            if (AId.Text == "" || ABrand.Text == "" || AModel.Text == "" ||  APrice.Text == ""||AStock.Text == "" )
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    // Open the connection
                    Con.Open();

                    // Define the SQL insert query for the Accessories table
                    string sql = "INSERT INTO Accessories (AId, ABrand, AModel, APrice,AStock) " +
                                 "VALUES (@AId, @ABrand, @AModel, @APrice, @AStock)";

                    // Create a SqlCommand and pass the query and connection object
                    SqlCommand cmd = new SqlCommand(sql, Con);

                    // Use parameterized queries to prevent SQL injection
                    cmd.Parameters.AddWithValue("@AId", int.Parse(AId.Text));  // Ensure AId is an integer
                    cmd.Parameters.AddWithValue("@ABrand", ABrand.Text);  // Ensure ABrand is a string
                    cmd.Parameters.AddWithValue("@AModel", AModel.Text);  // Ensure AModel is a string
                    cmd.Parameters.AddWithValue("@APrice", int.Parse(APrice.Text));  // Ensure AStock is an integer
                    cmd.Parameters.AddWithValue("@AStock", int.Parse(AStock.Text));  // Ensure APrice is an integer

                    // Execute the query
                    cmd.ExecuteNonQuery();

                    // Inform the user of success
                    MessageBox.Show("Accessory Added Successfully");

                    // Close the connection
                    Con.Close();

                    // Refresh the data grid view or perform any necessary post-insert operations
                    populate();
                }
                catch (Exception Ex)
                {
                    // Catch and display any errors that occur
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void AcessDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            AId.Text = AcessDGV.SelectedRows[0].Cells[0].Value.ToString();
            ABrand.Text = AcessDGV.SelectedRows[0].Cells[1].Value.ToString();
            AModel.Text = AcessDGV.SelectedRows[0].Cells[2].Value.ToString();
            APrice.Text = AcessDGV.SelectedRows[0].Cells[3].Value.ToString();
            AStock.Text = AcessDGV.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void Accessories_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            AId.Text = "";
            ABrand.Text = "";
            AModel.Text = "";
            APrice.Text = "";
            AStock.Text = "";
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            if (AId.Text == "")
            {
                MessageBox.Show("Enter the Accessoires ID to be deleted");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "DELETE FROM Accessories WHERE AId = @AId";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.Parameters.AddWithValue("@AId", int.Parse(AId.Text));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Acessoires Deleted");
                    Con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
                finally
                {
                    if (Con != null && Con.State == ConnectionState.Open)
                    {
                        Con.Close();
                    }
                }
            }
        }

        private void update_Click(object sender, EventArgs e)
        {
            if (AId.Text == "" || ABrand.Text == "" || AModel.Text == "" || APrice.Text == "" || AStock.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();

                    // Correct SQL update query
                    string sql = "UPDATE Accessories SET " +
                                 "ABrand = @ABrand, " +
                                 "AModel = @AModel, " +
                                 "APrice = @APrice, " +
                                 "AStock = @AStock " + // Removed the comma after AStock
                                 "WHERE AId = @AId";

                    SqlCommand cmd = new SqlCommand(sql, Con);

                    // Use parameterized queries to prevent SQL injection
                    cmd.Parameters.AddWithValue("@AId", int.Parse(AId.Text));
                    cmd.Parameters.AddWithValue("@ABrand", ABrand.Text);
                    cmd.Parameters.AddWithValue("@AModel", AModel.Text);
                    cmd.Parameters.AddWithValue("@APrice", int.Parse(APrice.Text));  // Ensure price is an integer
                    cmd.Parameters.AddWithValue("@AStock", int.Parse(AStock.Text));  // Ensure stock is an integer

                    // Execute the query
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Accessory Updated Successfully");

                    Con.Close();

                    // Refresh the data grid view to reflect the updates
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show();
            this.Hide();
        }

        private void AId_TextChanged(object sender, EventArgs e)
        {

        }
    }
}


