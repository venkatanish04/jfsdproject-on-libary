﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Diagnostics;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;
using System.Collections;
using System.Data.Entity.Infrastructure;
using System.Security.Cryptography;
namespace Mobile_Shop_Management_System
{
    public partial class Selling : Form
    {
        public Selling()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-0QOGVAC\SQLEXPRESS02;Initial Catalog=MobileTbl;Integrated Security=True");
        private void populate()
        {
            Con.Open();
            string query = "select Mbrand,Mmodel,Mprice from Mobile";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder buider = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            mobiledgv.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void populateAccess()
        {
            Con.Open();
            string query = "select ABrand,AModel,APrice from Accessories";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder buider = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            AcessDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void insertbill()
        {
            if (Bill.Text == "" || ClientName.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    int Amount = Convert.ToInt32(amount.Text);
                    string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");  // Current timestamp

                    using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-0QOGVAC\SQLEXPRESS02;Initial Catalog=MobileTbl;Integrated Security=True"))
                    {
                        con.Open();
                        string sql = "INSERT INTO Bill (BillId, ClientName, Amt, Timestamp) VALUES (@BillId, @ClientName, @Amt, @Timestamp)";
                        using (SqlCommand cmd = new SqlCommand(sql, con))
                        {
                            cmd.Parameters.AddWithValue("@BillId", int.Parse(Bill.Text));
                            cmd.Parameters.AddWithValue("@ClientName", ClientName.Text);
                            cmd.Parameters.AddWithValue("@Amt", Amount);
                            cmd.Parameters.AddWithValue("@Timestamp", timestamp); // Add Timestamp to SQL parameters

                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Bill Added Successfully");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }






        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
        
        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Selling_Load(object sender, EventArgs e)
        {
            populate();
            populateAccess();
            sum();
        }
        private void sum()
        {
            try
            {
                string query = "SELECT SUM(Amt) FROM Bill";
                Con.Open();
                SqlDataAdapter sda = new SqlDataAdapter(query, Con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count > 0 && dt.Rows[0][0] != DBNull.Value)
                {
                    SellsAmount.Text = dt.Rows[0][0].ToString(); // Display the sum of amounts
                }
                else
                {
                    SellsAmount.Text = "0"; // If no records, show 0
                }
                Con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void label9_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mobiledgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Ensure the user clicked on a valid row
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = mobiledgv.Rows[e.RowIndex];

                // Assuming you have TextBoxes named ProductTextBox and PriceTextBox
                // Assign the appropriate cell values to your TextBoxes
                product1.Text = row.Cells["Mmodel"].Value.ToString();  // Assuming Mmodel is the column name
                price1.Text = row.Cells["Mprice"].Value.ToString();    // Assuming Mprice is the column name
            }
        }



        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void AcessDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Ensure the user clicked on a valid row
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = AcessDGV.Rows[e.RowIndex];  // Corrected to AcessDGV

                // Assign the appropriate cell values to your TextBoxes
                product1.Text = row.Cells["AModel"].Value.ToString();  // Assuming AModel is the column name
                price1.Text = row.Cells["APrice"].Value.ToString();    // Assuming APrice is the column name
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        
        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }
        private void button3_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show();
            this.Hide();
        }

        int proid, prodquantity, prodprice, tottal, pos = 60;
        string prodname;

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            // Get the current date and time
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            // Printing the header
            e.Graphics.DrawString("MOBILESHOP", new Font("Century Gothic", 12, FontStyle.Bold), Brushes.Blue, new Point(80, 15));
            e.Graphics.DrawString("ID   PRODUCT   PRICE   QUANTITY   TOTAL", new Font("Century Gothic", 12, FontStyle.Bold), Brushes.Blue, new Point(20, 40));

            // Print the timestamp at the top-right corner
            e.Graphics.DrawString("Date: " + timestamp, new Font("Century Gothic", 10, FontStyle.Regular), Brushes.Black, new Point(400, 15));

            // Loop through rows and print the bill details
            foreach (DataGridViewRow row in BillDGV.Rows)
            {
                // Check if the row is valid
                if (row.Cells["Column1"].Value != null)
                {
                    proid = Convert.ToInt32(row.Cells["Column1"].Value);        // Assuming Column1 stores Product ID
                    prodname = row.Cells["Column2"].Value.ToString();           // Assuming Column2 stores Product Name
                    prodprice = Convert.ToInt32(row.Cells["Column3"].Value);    // Assuming Column3 stores Price
                    prodquantity = Convert.ToInt32(row.Cells["Column4"].Value); // Assuming Column4 stores Quantity
                    tottal = Convert.ToInt32(row.Cells["Column5"].Value);       // Assuming Column5 stores Total

                    // Print each row
                    e.Graphics.DrawString(proid.ToString(), new Font("Century Gothic", 10, FontStyle.Regular), Brushes.Black, new Point(20, pos));
                    e.Graphics.DrawString(prodname, new Font("Century Gothic", 10, FontStyle.Regular), Brushes.Black, new Point(60, pos));
                    e.Graphics.DrawString(prodprice.ToString(), new Font("Century Gothic", 10, FontStyle.Regular), Brushes.Black, new Point(150, pos));
                    e.Graphics.DrawString(prodquantity.ToString(), new Font("Century Gothic", 10, FontStyle.Regular), Brushes.Black, new Point(220, pos));
                    e.Graphics.DrawString(tottal.ToString(), new Font("Century Gothic", 10, FontStyle.Regular), Brushes.Black, new Point(300, pos));

                    // Increment position for the next row
                    pos += 20;
                }
            }

            // Print Grand Total
            e.Graphics.DrawString("Grand Total Rs " + Grdtotal, new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Crimson, new Point(50, pos + 50));
            e.Graphics.DrawString("*********MOBILESHOP********", new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Crimson, new Point(50, pos + 85));

            // Clear the BillDGV after printing
            BillDGV.Rows.Clear();
            BillDGV.Refresh();

            // Reset variables for the next bill
            pos = 100;
            Grdtotal = 0;
            n = 0;
            insertbill();
            sum();
        }



        private void button2_Click(object sender, EventArgs e)
        {
            // Set paper size for the document
            printDocument1.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("pprnm", 285, 600);

            // Show print preview and print if confirmed
            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument1.Print();
            }
        }


        // int uprice;
        int n = 0, Grdtotal = 0; // Declare n as a class-level variable
        private void button1_Click(object sender, EventArgs e)
        {
            if (Quantity1.Text == "" || price1.Text == "")
            {
                MessageBox.Show("Enter The Quantity");
            }
            else
            {
                // Calculate total as Quantity * Price
                int quantity = Convert.ToInt32(Quantity1.Text);
                int price = Convert.ToInt32(price1.Text);
                int total = quantity * price;

                // Create a new row for the BillDGV
                DataGridViewRow newRow = new DataGridViewRow();
                newRow.CreateCells(BillDGV);

                // Increment n to maintain the serial number
                n++;
                Grdtotal = Grdtotal + total;
                amount.Text = Grdtotal.ToString();

                newRow.Cells[0].Value = n;              // Serial Number
                newRow.Cells[1].Value = product1.Text;  // Product Name
                newRow.Cells[2].Value = price1.Text;    // Price
                newRow.Cells[3].Value = Quantity1.Text; // Quantity
                newRow.Cells[4].Value = total;          // Total

                // Add the row to the BillDGV
                BillDGV.Rows.Add(newRow);
            }
        }


    }
}

