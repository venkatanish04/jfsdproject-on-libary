﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mobile_Shop_Management_System
{
    public partial class Mobile : Form
    {
        public Mobile()
        {
            InitializeComponent();
        }

        SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-0QOGVAC\SQLEXPRESS02;Initial Catalog=MobileTbl;Integrated Security=True");

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void populate()
        {
            Con.Open();
            string query = "select * from Mobile";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder buider = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            mobiledgv.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Mobile_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Mobid.Text == "" || brand.SelectedItem == null || model.Text == "" || price.Text == "" || stock.Text == "" || ram.SelectedItem == null || rom.SelectedItem == null || cam.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string sql = "INSERT INTO Mobile (Mobid, Mbrand, MModel, MPrice, MStock, MRam, MRom, MCam) " +
                                 "VALUES (@Mobid, @Mbrand, @MModel, @MPrice, @MStock, @MRam, @MRom, @MCam)";
                    SqlCommand cmd = new SqlCommand(sql, Con);

                    // Use parameterized queries to prevent SQL injection
                    cmd.Parameters.AddWithValue("@Mobid", int.Parse(Mobid.Text));  // Ensure Mobid is provided
                    cmd.Parameters.AddWithValue("@Mbrand", brand.SelectedItem.ToString());  // Get selected item as string
                    cmd.Parameters.AddWithValue("@MModel", model.Text);
                    cmd.Parameters.AddWithValue("@MPrice", int.Parse(price.Text));
                    cmd.Parameters.AddWithValue("@MStock", int.Parse(stock.Text));
                    cmd.Parameters.AddWithValue("@MRam", int.Parse(ram.SelectedItem.ToString()));
                    cmd.Parameters.AddWithValue("@MRom", int.Parse(rom.SelectedItem.ToString()));
                    cmd.Parameters.AddWithValue("@MCam", int.Parse(cam.Text));

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Mobile Added Successfully");
                    Con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }



        private void mobiledgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (mobiledgv.SelectedRows.Count > 0)
            {
                Mobid.Text = mobiledgv.SelectedRows[0].Cells[0].Value.ToString();
                brand.SelectedItem = mobiledgv.SelectedRows[0].Cells[1].Value.ToString();
                model.Text = mobiledgv.SelectedRows[0].Cells[2].Value.ToString();
                price.Text = mobiledgv.SelectedRows[0].Cells[3].Value.ToString();
                stock.Text = mobiledgv.SelectedRows[0].Cells[4].Value.ToString();
                ram.SelectedItem = mobiledgv.SelectedRows[0].Cells[5].Value.ToString();
                rom.SelectedItem = mobiledgv.SelectedRows[0].Cells[6].Value.ToString();
                cam.Text = mobiledgv.SelectedRows[0].Cells[7].Value.ToString();
            }
            else
            {
                MessageBox.Show("Please select a row first.");
            }
        }


        private void button4_Click(object sender, EventArgs e)
        {
            Mobid.Text = "";
            brand.SelectedIndex = -1;
            model.Text = "";
            price.Text = "";
            stock.Text = "";
            cam.Text = "";
            ram.SelectedIndex = -1;  // Clear ComboBox selection
            rom.SelectedIndex = -1;  // Clear ComboBox selection
        }


        private void button3_Click(object sender, EventArgs e)
        {

            if (Mobid.Text == "")
            {
                MessageBox.Show("Enter the mobile ID to be deleted");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "DELETE FROM Mobile WHERE Mobid = @Mobid";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.Parameters.AddWithValue("@Mobid", int.Parse(Mobid.Text));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Mobile Deleted");
                    Con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
                finally
                {
                    if (Con != null && Con.State == ConnectionState.Open)
                    {
                        Con.Close();
                    }
                }
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            if (Mobid.Text == "" || brand.SelectedItem == null || model.Text == "" || price.Text == "" || stock.Text == "" || ram.SelectedItem == null || rom.SelectedItem == null || cam.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    int mobid = int.Parse(Mobid.Text); // Get the Mobid from the input field

                    Con.Open();
                    string sql = "UPDATE Mobile SET " +
                        "Mbrand = @Mbrand, " +
                        "MModel = @MModel, " +
                        "MPrice = @MPrice, " +
                        "MStock = @MStock, " +
                        "MRam = @MRam, " +
                        "MRom = @MRom, " +
                        "MCam = @MCam " +
                        "WHERE Mobid = @Mobid"; // Add the WHERE clause

                    SqlCommand cmd = new SqlCommand(sql, Con);

                    // Use parameterized queries to prevent SQL injection
                    cmd.Parameters.AddWithValue("@Mbrand", brand.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@MModel", model.Text);
                    cmd.Parameters.AddWithValue("@MPrice", int.Parse(price.Text));
                    cmd.Parameters.AddWithValue("@MStock", int.Parse(stock.Text));
                    cmd.Parameters.AddWithValue("@MRam", int.Parse(ram.SelectedItem.ToString()));
                    cmd.Parameters.AddWithValue("@MRom", int.Parse(rom.SelectedItem.ToString()));
                    cmd.Parameters.AddWithValue("@MCam", int.Parse(cam.Text));
                    cmd.Parameters.AddWithValue("@Mobid", mobid); // Add Mobid to parameters

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Mobile updated Successfully");
                    Con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
                finally
                {
                    if (Con != null && Con.State == ConnectionState.Open)
                    {
                        Con.Close();
                    }
                }
            }
        }


        private void button5_Click(object sender, EventArgs e)
        {

            Home home = new Home();
            home.Show();
            this.Hide();
        }

        private void brand_TextChanged(object sender, EventArgs e)
        {

        }

        private void Mobid_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void model_TextChanged(object sender, EventArgs e)
        {

        }
    }
}